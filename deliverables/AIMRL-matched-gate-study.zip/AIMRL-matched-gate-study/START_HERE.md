# Matched-training gate study

Open revision/matched-gate-results/README.md first for the actual outcome, all comparisons and limitations. Open deliverables/AIMRL-matched-gate-figures.pdf for all eight figures, or revision/matched-gate-results/index.html for an embedded-image report.

This is a NEW matched-adaptation experiment: eight paired seeds each for DQN/MAPPO; ALL, SAFE, VALUE and COMBINED arms; 64 final checkpoints; complete training/validation/auxiliary value data, final episode/convoy records, fixed-actor diagnostics, source and tests. Large tables are CSV.gz. The safeguards-only baseline here uses exactly the combined arm's constraints and differs from the earlier SAFE-ALL implementation.

Read revision/matched-gate-protocol.md for the predeclared hypotheses, fixed settings and full reproduction commands. Run bash setup_local.sh to recreate the pinned environment. All previous studies and downloadable packages remain separately available in the GitHub branch; their datasets are not duplicated in this package.

Primary comparisons include actor adaptation after a common warmup. Learned arms additionally use causal replay labels; compute is not equal. Fixed-actor swaps are descriptive. No broad superiority, convergence, bandwidth savings or operational-validation claim is warranted.
