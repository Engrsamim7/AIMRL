# Communication opportunity audit package

Open revision/communication-opportunity-audit/index.html for the six-figure offline report, or communication_opportunity_report.pdf in that folder. README.md in the report folder defines the diagnostics and caveats. Read revision/communication-audit-next-experiments.md for the proposed fresh experiment design.

This ZIP includes all source, original frozen model weights and executed adaptive results from the previous verified package, plus audit code and raw audit tables. Raw large CSVs are shipped as CSV.gz. No original evaluated simulator or gate source was changed; no new training or superiority claim is made. BASE_BUNDLE_MANIFEST.json records the earlier package.

Run bash setup_local.sh from the package directory to install pinned dependencies; reproduction commands are in the audit README.
