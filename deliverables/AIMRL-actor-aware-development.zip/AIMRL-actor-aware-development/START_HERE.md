# Actor-aware fleet-value development

Start with revision/actor-aware-development-findings.md and revision/actor-aware-development-results/README.md. Open actor_aware_development.pdf or index.html in that report folder for six figures.

This is development evidence, not a new superiority confirmation. Sixteen parent SAFE-trained actors are frozen existing checkpoints, not new routing-training seeds. The32 new forest estimators use complete-inbox public actor probes and fleet-value labels. One learned override is allowed over the entire fleet episode, then SAFE resumes. Tree dispersion is heuristic, not calibrated safety.

Includes full simulator/new-study Python source, parent SAFE inference checkpoints, new estimators in non-pickle NPZ form, selected intervention labels with both full-fleet branches as JSON CSV cells, all6144 factual development episodes,39936 calibration method episodes,6144 audit method episodes/30720 convoy records, settings, tables and figures. Older studies and their raw data remain in separate historical ZIPs.

Reproduce from extracted root: bash setup_local.sh; .venv/bin/python -m pip install -r requirements-actor-aware.txt. See report README for exact commands. Inference forest loading uses NumPy; fitting additionally requires the pinned scikit-learn packages. Routing checkpoints support inference, not exact optimizer/replay training resumption. Every listed file has a SHA-256 hash in BUNDLE_MANIFEST.json.
