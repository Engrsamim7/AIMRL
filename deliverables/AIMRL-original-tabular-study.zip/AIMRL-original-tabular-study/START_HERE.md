# Original tabular AMMARL: reproduction and repairs

Start with revision/original-tabular-findings.md and revision/original-tabular-results/README.md. Open original_tabular_report.pdf or index.html in that report folder for eight figures.

The original hub-indexed tabular Q learner and fixed FRC gate are retained. Original AMMARL/IQL route scores reproduce 0.876/0.857, but actual delivery is 100% and original M4 hazard use is zero. The original ungated 0.851 presentation score is not reproduced. Repaired FRC and ALL also tie in this test. These findings do not establish gate superiority or survival probability.

Includes all 17 byte-preserved uploads and their inventory, full simulator Python source, 25 historical inference models, five closest-repair models, 80 controlled models, raw training/validation/evaluation records, locked settings, CSV tables and eight figures. Prior studies remain in separate historical ZIPs; their raw data are not duplicated here.

From the extracted root run bash setup_local.sh. The new tabular study uses the base pinned requirements. Install requirements-actor-aware.txt additionally to run all historical regression tests: .venv/bin/python -m pip install -r requirements-actor-aware.txt. Then .venv/bin/python -m pytest simulator/tests*.py. See the report README for study/report commands. Use the same Python 3.12 environment for reproducibility. Checkpoints support inference, not exact interrupted-training resumption. SHA-256 hashes are in BUNDLE_MANIFEST.json.
