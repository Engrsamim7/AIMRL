# Implemented pre-transmission mechanism pilot

Read revision/pretransmission-opportunity-findings.md first. Open the three-page
PDF or offline index.html in revision/pretransmission-opportunity-results/.

This is a completed mechanism pilot with frozen routing, not a trained new
communication controller or a superiority confirmation. It includes1104 factual
episodes,1104 full batched-priority reference episodes,3017 isolated alternative
continuations and41800 convoy outcome records. Sampled hindsight opportunity
must not be called a deployable or learned result. All conditions and harms stay.

The package contains complete source, original submitted code, all eight selected
routing checkpoints (including one initial-policy selection), calibration,
prospective design, raw episode/convoy/paired-branch records, tables and figures.
Prior studies and their bulky raw logs remain in separate historical ZIPs.

Install bash setup_local.sh, then
.venv/bin/python -m pip install -r requirements-actor-aware.txt
Run from this extracted root, with MPLCONFIGDIR=/tmp/aimrl-mpl
XDG_CACHE_HOME=/tmp/aimrl-cache OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1:
.venv/bin/python -m pytest -q simulator/tests_*.py
.venv/bin/python simulator/run_pretransmission_opportunity.py --output simulator/out/pretransmission-reproduction
.venv/bin/python simulator/report_pretransmission_opportunity.py --run simulator/out/pretransmission-reproduction

A fresh run folder is required. Actor/gate learning is not part of this pilot.
The shared-MAC queue controller does not read live remote states or future truth.
Deferral affects only the selected packet and leaves service available to others.
The original engine, routing checkpoints and previous study archives are preserved.
