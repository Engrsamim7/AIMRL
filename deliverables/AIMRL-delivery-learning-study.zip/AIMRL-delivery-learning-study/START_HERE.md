# Delivery-primary learned routing and causal gate

Read revision/delivery-learning-findings.md for actual results and limitations.
Open revision/delivery-learning-results/delivery_learning_report.pdf or index.html
for seven figures; summary.csv and primary_contrasts.csv contain primary results.

The package contains complete simulator source, the original submitted code,
eight selected routing checkpoints and all checkpoint candidates, eight gate
estimators, all training and validation records, complete paired causal labels,
locked settings, raw held-out episode/convoy/gate decisions, tables and figures.
Both stopped development passes and their exact source are retained separately;
neither executed held-out testing. Earlier studies have separate archives.

Install with bash setup_local.sh, followed by
.venv/bin/python -m pip install -r requirements-actor-aware.txt.
Run from this extracted root. Full commands are in the results README.
The fixed parent calibration file is included at its original relative path.
Models support inference, not exact optimizer/replay training resumption.

Fleet on-time delivery is the objective. The common frozen routing policies
isolate gate effects; comparators are not each independently retrained for their
receiver. The gate has one shared fleet rejection token. Tree dispersion is
heuristic uncertainty. Neither universal superiority, learning convergence,
fully decentralized coordination nor operational validity is established.
