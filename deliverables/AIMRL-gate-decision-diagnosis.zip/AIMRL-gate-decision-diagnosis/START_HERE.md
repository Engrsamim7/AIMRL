# Gate decision diagnosis

Read revision/gate-decision-diagnosis-findings.md for the evidence and concrete next-design recommendation. Open revision/gate-decision-diagnosis/gate_decision_diagnosis.pdf or index.html for seven figures. Its README.md contains all diagnostic tables and limitations.

This package contains full simulator/diagnostic source; 64 original final routing checkpoints and 16 reconstructed hash-verified warmup checkpoints; the original fitted value models; all matched-study data for context; all eligible diagnostic packet records; selected full/prefix accept-versus-reject effects with complete per-branch convoy outcomes encoded as JSON in CSV cells; static-rule outcomes; and new warmup/adapted prediction labels. Large tables are CSV.gz.

No original gate or final actor was changed or refitted. The reconstructed warmup actors reproduce original weights; they are not additional independent training seeds. Selection is chronological and stratified, and all diagnostic findings are exploratory. These datasets must not be used as a fresh held-out superiority trial for a gate redesigned using their outcomes.

Run bash setup_local.sh to create the pinned environment. Reproduction commands are in revision/gate-decision-diagnosis-protocol.md and the diagnostic report README. Use a new output folder when rerunning. Earlier historical packages remain separately available in GitHub.
