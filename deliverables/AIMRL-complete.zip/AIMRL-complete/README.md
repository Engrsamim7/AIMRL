# AIMRL complete simulator package

This package includes the complete reconstructed simulator code, 36 fitted models,
raw convoy/episode CSVs, manifests, logs, audit results, nine PNG/vector-PDF figures,
and an offline report. Training-worker and aggregated checkpoints are copies of the
same models, not additional training. Original manuscripts/review letters,
credentials, environments, caches and old result archives are excluded.

Start by opening `revision/complete-visualisations/index.html` in a browser.
It contains the figures and scenario selector and works without Internet access.
The seven-page comparison PDF is `revision/complete-visualisations/updated_results_report.pdf`.
The two-page episode PDF is `revision/complete-visualisations/simulation_episode_report.pdf`.

## Run the code

The executed environment used Python 3.12 on Linux and CPU PyTorch.
Linux, WSL or a comparable Linux notebook environment is recommended.

```bash
bash setup_local.sh
source .venv/bin/activate
cd simulator
python -m pytest -q tests_core.py tests_revision.py
python validate_results.py out/complete-model-v1
python run_complete.py --output out/my-new-run --figures ../revision/my-new-figures
```

The full command retrains and regenerates all results. It requires fresh output
directories and may take substantial CPU time. Defaults are 300 episodes/model,
three training seeds, 12 convoys and four workers. No operational data or service
credential is required. To regenerate figures from the included results:

```bash
python plot_updated_results.py --run-root out/complete-model-v1 --output ../revision/regenerated
python build_report.py --run-root out/complete-model-v1 --figures ../revision/regenerated
```

Read `simulator/METHODS.md` for dynamics, observation, gate, learning and metric
definitions. Read `revision/complete-protocol.md` for the executed design.
Results are synthetic and exploratory; a complete implementation does not imply
convergence, real-world validation or consistent gate superiority.

`BUNDLE_MANIFEST.json` records SHA-256 hashes of every packaged file.
Source SHA-256: `596294a014a198d970957e41fc6bf55b92563518b0e73ac507159553cb50babd`.
