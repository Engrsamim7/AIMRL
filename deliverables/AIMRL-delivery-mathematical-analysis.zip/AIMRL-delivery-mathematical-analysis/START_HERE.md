# Delivery mathematical diagnosis and controlled development ablation

Read revision/delivery-mathematical-analysis.md for the equations, evidence and
proposed design. The main numeric audit/figure is in
revision/delivery-mathematical-analysis/. No new superiority claim is made.

This supplement contains the audit code, complete simulator source, original
submitted code, numeric inputs, original frozen actors/gates/causal training
labels, saved validation contexts, the target-scale ablation models/results,
and the original published report tables. It excludes bulky original test
packet/convoy logs; those remain in AIMRL-delivery-learning-study.zip:
https://raw.githubusercontent.com/Engrsamim7/AIMRL/reviewer-complete-model-20261012/deliverables/AIMRL-delivery-learning-study.zip

Use the project environment, or bash setup_local.sh followed by
.venv/bin/python -m pip install -r requirements-actor-aware.txt.
The audit alone needs numpy2.3.5, pandas2.2.3 and matplotlib3.10.8.
Run from this extracted root:
.venv/bin/python simulator/analyze_delivery_gap.py

To repeat the controlled development ablation, use a FRESH destination:
.venv/bin/python simulator/run_delivery_value_scale_ablation.py --output simulator/out/value-scale-reproduction --report revision/value-scale-reproduction

Use MPLCONFIGDIR=/tmp/aimrl-mpl XDG_CACHE_HOME=/tmp/aimrl-cache
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 for both commands.
The ablation uses already-seen validation contexts only. It re-fits eight gates,
retains five fixed settings and runs960 validation method episodes. It reproduces
the eight original estimators exactly before fitting a different target scale.
No new test is run. The fixed-setting scale change did not improve observed
validation delivery. Richer beliefs, deadline-return critics and pre-transmission
control remain proposals, not implemented performance claims in this supplement.
