# Dynamic-recovery learned gate study

Read revision/recovery-gate-findings.md for the claim and limitations; revision/recovery-gate-results/README.md for complete tables; open revision/recovery-gate-results/recovery_gate_report.pdf or index.html for eight figures.

This package contains full Python source,80 final routing checkpoints,32 initial/refreshed gate estimators, all training records, paired causal labels with accept/reject convoy outcomes encoded as JSON in CSV cells, validation candidates and locked settings,102400 final-test method episodes (512000 convoy records),7680 descriptive fixed-actor ablation episodes, all result tables and figures. Large tables are CSV.gz. These routing checkpoints support inference; optimizer/replay state is not serialized for exact training resumption. Rerun training from the deterministic source workflow. Older study raw data are in their separate historical ZIPs.

Run bash setup_local.sh for the pinned environment. Reproduction commands are in revision/recovery-gate-results/README.md and the prospective protocol. Run from the extracted root. Use a fresh output folder for a new experiment.

The gate cannot access hidden hazard schedules or real packet origin. Its estimated risk and bootstrap disagreement are heuristic, not calibrated safety guarantees. Utility success requires delivery noninferiority within a declared simulation tolerance; this is not operational validation or universal superiority. Auxiliary label fitting has extra compute. All test conditions and failures are retained.
