# Reviewer revision package

Open revision/reviewer-revision-results/index.html for all nine figures and tables without a server. Read revision/reviewer-code-changes.md for implementation changes, assumptions and reproduction commands. Use bash setup_local.sh from this directory to install pinned dependencies. The current executed run is simulator/out/reviewer-revision-v2; v1 and supplied submission code are preserved as historical references. Current report audits passed and 43 tests passed. General gate superiority and convergence remain unestablished.
