# Journal-readiness diagnosis: the current superiority manuscript is not ready

Start with revision/journal-readiness-assessment.md. Open revision/journal-readiness/journal_readiness.pdf or index.html for four figures. The original-family study is archived unchanged; the new audit reproduces its outcomes and finds no ALL/FRC/NONE next-hop changes across 518,400 frozen-policy decisions. None offers a physically blocked available outgoing option.

The 432-cell exact decision benchmark is model validation, NOT a new logistics/MARL performance experiment. It uses known closure dynamics and calibrated sensor accuracy to demonstrate the limits of fixed freshness filtering and the role of an age-aware baseline. It does not establish journal readiness, combat survival, general superiority or a deployed learned gate.

Includes complete simulator source, all 17 preserved uploads, the original-tabular parent raw data and 110 inference checkpoints, all audit decisions, exact-reference cells and branches, tables, figures, protocol and an explicitly prospective next-network acceptance contract. Other historical study data remain in their original ZIPs.

Reproduce from extracted root: bash setup_local.sh. Install requirements-actor-aware.txt additionally to run all historical tests, then .venv/bin/python -m pytest simulator/tests*.py. The current suite has 129 tests. Use Python 3.12. The new audit and exact reference only require the base environment. See revision/journal-readiness/README.md for reproduction commands. Set MPLCONFIGDIR=/tmp/aimrl-mpl XDG_CACHE_HOME=/tmp/aimrl-cache OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1. BUNDLE_MANIFEST.json records every included file hash.
