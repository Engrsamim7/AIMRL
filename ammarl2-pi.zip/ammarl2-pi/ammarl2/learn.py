"""Learned routing: GNN edge-scoring network with DQN / PPO / IPPO / MAPPO training.

* Same belief machinery (own obs + gated peer messages) feeds the network, so the gate is
  the ONLY difference between e.g. DQN-NC and DQN-GATE.
* Action masking: candidates are out-edges of the current node whose head can still reach
  the convoy's target (hard mask, applied before softmax / argmax).
* Online learning from sim transitions (no post-hoc replay, no monkeypatching).
"""
import random
from dataclasses import dataclass
import heapq
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from .policies import Policy

FN, FE, FG = 7, 6, 4
DEATH_PEN = 40.0
_GC = {}


def _revdist(g, tgt):
    inn = [[] for _ in range(g.n)]
    for e in range(g.m):
        inn[int(g.dst[e])].append(e)
    d = np.full(g.n, np.inf); d[tgt] = 0
    h = [(0.0, tgt)]
    while h:
        du, v = heapq.heappop(h)
        if du > d[v]:
            continue
        for e in inn[v]:
            u = int(g.src[e]); nd = du + g.c[e]
            if nd < d[u]:
                d[u] = nd; heapq.heappush(h, (nd, u))
    return d


def gctx(g):
    key = (g.n, g.m, g.c.tobytes())
    if key not in _GC:
        A = np.eye(g.n, dtype=np.float32)
        for e in range(g.m):
            A[g.src[e], g.dst[e]] = 1; A[g.dst[e], g.src[e]] = 1
        A = A / A.sum(1, keepdims=True)
        rd = {t: _revdist(g, t) for t in g.targets}
        scale = max(v[np.isfinite(v)].max() for v in rd.values())
        if len(_GC) > 64:
            _GC.clear()
        _GC[key] = (torch.tensor(A), rd, float(scale))
    return _GC[key]


class Ctx:
    __slots__ = ("X", "A", "u", "dst", "EF", "edges", "glob")


def build_ctx(sim, cv, ban, merged, t, tau_stale):
    g = sim.g
    A, rd, sc = gctx(g)
    d = rd[cv.target]
    X = np.zeros((g.n, FN), np.float32)
    X[:, 2] = np.where(np.isfinite(d), d / sc, 1.5)
    X[cv.node, 0] = 1; X[cv.target, 1] = 1
    X[:, 3] = sim.busy / max(1, sim.cfg.hub_cap)
    X[:, 4] = [len(q) / 4 for q in sim.queue]
    for u in range(g.n):
        oe = g.out[u]
        if oe:
            X[u, 5] = np.mean([e in ban for e in oe]); X[u, 6] = g.rho[oe].mean()
    edges = [e for e in g.out[cv.node] if np.isfinite(d[int(g.dst[e])])]
    EF = np.zeros((len(edges), FE), np.float32)
    for k, e in enumerate(edges):
        b = merged.get(e)
        age = (t - b[1]) / tau_stale if (b and b[0] and e in ban) else 0.0
        EF[k] = [g.c[e] / 5, g.rho[e], sim.flow[e] / g.q[e], float(e in ban), age, d[int(g.dst[e])] / sc]
    c = Ctx()
    c.X, c.A = torch.tensor(X), A
    c.u = cv.node
    c.dst = torch.tensor([int(g.dst[e]) for e in edges])
    c.EF = torch.tensor(EF); c.edges = edges
    alive = sum(1 for o in sim.cv if o.alive and not o.delivered)
    c.glob = torch.tensor([len(sim.active) / max(1, sim.cfg.budget), alive / len(sim.cv),
                           float(np.mean(sim.flow / g.q)), float(sim.busy.sum() / (g.n * sim.cfg.hub_cap))],
                          dtype=torch.float32)
    return c


class Net(nn.Module):
    def __init__(s, hid=48, central=False):
        super().__init__()
        s.central = central
        s.inp = nn.Linear(FN, hid); s.g1 = nn.Linear(2 * hid, hid); s.g2 = nn.Linear(2 * hid, hid)
        s.eh = nn.Sequential(nn.Linear(2 * hid + FE, hid), nn.ReLU(), nn.Linear(hid, 1))
        s.vh = nn.Sequential(nn.Linear(hid + (FG if central else 0), hid), nn.ReLU(), nn.Linear(hid, 1))

    def forward(s, c):
        h = F.relu(s.inp(c.X))
        h = F.relu(s.g1(torch.cat([h, c.A @ h], 1)))
        h = F.relu(s.g2(torch.cat([h, c.A @ h], 1)))
        sc = s.eh(torch.cat([h[c.u].expand(len(c.dst), -1), h[c.dst], c.EF], 1)).squeeze(1)
        v = s.vh(torch.cat([h[c.u], c.glob]) if s.central else h[c.u]).squeeze()
        return sc, v


@dataclass
class LearnedPolicy(Policy):
    algo: str = "dqn"            # dqn | ppo | ippo | mappo
    train: bool = False
    eps: float = 0.0
    seed: int = 0

    def __post_init__(self):
        torch.manual_seed(self.seed); random.seed(self.seed)
        self.net = Net(central=(self.algo == "mappo"))
        self.opt = torch.optim.Adam(self.net.parameters(), lr=1e-3)
        if self.algo == "dqn":
            self.tgt = Net(); self.tgt.load_state_dict(self.net.state_dict())
            self.buf, self.nupd, self.nstep = [], 0, 0
        self.pend, self.traj, self.rng = {}, {}, np.random.default_rng(self.seed)

    # ---- acting
    def select(self, sim, cv, w, ban, merged, t):
        c = build_ctx(sim, cv, ban, merged, t, sim.cfg.tau_stale)
        if not c.edges:
            return self._first(sim.g, cv, w, ban)
        with torch.no_grad():
            sc, v = self.net(c)
        if self.algo == "dqn":
            a = int(self.rng.integers(len(c.edges))) if (self.train and self.rng.random() < self.eps) else int(sc.argmax())
            lp = 0.0
        else:
            dist = torch.distributions.Categorical(logits=sc)
            a = int(dist.sample()) if self.train else int(sc.argmax())
            lp = float(dist.log_prob(torch.tensor(a)))
        if self.train:
            self._advance(cv, c, t)
            self.pend[cv.id] = (c, a, t, lp, float(v))
        return c.edges[a]

    def _advance(self, cv, c_next, t, done=False, death=False):
        p = self.pend.pop(cv.id, None)
        if p is None:
            return
        c, a, t0, lp, v = p
        r = -(t - t0) - (DEATH_PEN if death else 0.0)
        if self.algo == "dqn":
            self.buf.append((c, a, r, c_next, done))
            self.buf = self.buf[-20000:]
            self.nstep += 1
            if self.nstep % 8 == 0 and len(self.buf) >= 256:
                self._dqn_update()
        else:
            self.traj.setdefault(cv.id, []).append([c, a, lp, v, r, done])

    def terminal(self, sim, cv, t, death):
        if self.train:
            self._advance(cv, None, t, done=True, death=death)

    # ---- DQN
    def _dqn_update(self, bs=32, gamma=0.99):
        batch = random.sample(self.buf, bs)
        loss = 0
        for c, a, r, cn, done in batch:
            q = self.net(c)[0][a]
            with torch.no_grad():
                y = r if (done or cn is None or not cn.edges) else r + gamma * float(self.tgt(cn)[0].max())
            loss = loss + F.smooth_l1_loss(q, torch.tensor(float(y)))
        self.opt.zero_grad(); (loss / bs).backward()
        nn.utils.clip_grad_norm_(self.net.parameters(), 5.0); self.opt.step()
        self.nupd += 1
        if self.nupd % 100 == 0:
            self.tgt.load_state_dict(self.net.state_dict())

    # ---- PPO family
    def end_episode(self, gamma=0.99, lam=0.95, epochs=4, clip=0.2):
        if self.algo == "dqn" or not self.traj:
            self.pend.clear(); self.traj.clear(); return
        data = []
        for tr in self.traj.values():
            adv, last = 0.0, 0.0
            for i in range(len(tr) - 1, -1, -1):
                c, a, lp, v, r, done = tr[i]
                nv = 0.0 if (done or i == len(tr) - 1) else tr[i + 1][3]
                delta = r + gamma * nv - v
                adv = delta + gamma * lam * adv
                data.append((c, a, lp, adv, adv + v))
        adv_all = torch.tensor([d[3] for d in data])
        adv_n = (adv_all - adv_all.mean()) / (adv_all.std() + 1e-6) if len(data) > 1 else adv_all
        for _ in range(epochs):
            idx = list(range(len(data))); random.shuffle(idx)
            for s in range(0, len(idx), 64):
                loss = 0; mb = idx[s:s + 64]
                for i in mb:
                    c, a, lp0, _, ret = data[i]
                    sc, v = self.net(c)
                    dist = torch.distributions.Categorical(logits=sc)
                    ratio = torch.exp(dist.log_prob(torch.tensor(a)) - lp0)
                    A_ = adv_n[i]
                    loss = loss - torch.min(ratio * A_, torch.clamp(ratio, 1 - clip, 1 + clip) * A_) \
                        + 0.5 * F.mse_loss(v, torch.tensor(float(ret)) / 20) * 0 + 0.5 * F.mse_loss(v, torch.tensor(float(ret))) / 100 \
                        - 0.01 * dist.entropy()
                self.opt.zero_grad(); (loss / len(mb)).backward()
                nn.utils.clip_grad_norm_(self.net.parameters(), 5.0); self.opt.step()
        self.traj.clear(); self.pend.clear()
