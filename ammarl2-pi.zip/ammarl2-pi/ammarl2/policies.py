"""Routing policies. One shared `decide` code path; methods differ ONLY in flags."""
from dataclasses import dataclass
from .graph import dijkstra, dists


@dataclass
class Policy:
    name: str
    weights: str = "c"          # 'c' (least cost) | 'threat' (c*(1+alpha*rho))
    alpha: float = 6.0
    use_obs: bool = False       # replan on own local observations
    comm: str = "none"          # none | all | gate | oracle
    gate_fresh: bool = True
    gate_rel: bool = True
    gate_conf: bool = True
    eta: float = 0.40
    scaling: str = "static"     # static: eta*tau_stale ; scaled: eta*(ETA_to_edge + tau_msg)
    kappa_min: float = 0.60
    noise: float = 0.0          # multiplicative lognormal weight noise (route diversification)

    def w(self, g):
        return g.c if self.weights == "c" else g.c * (1 + self.alpha * g.rho)

    def banned(self, belief, t, tau_stale):
        return {e for e, (b, to, cf) in belief.items() if b and t - to <= tau_stale}

    def decide(self, sim, cv, t):
        g, cfg = sim.g, sim.cfg
        w = self.w(g)
        if self.noise > 0:
            import numpy as _np
            w = w * _np.exp(self.noise * _np.random.default_rng([sim.seed, cv.id, int(t * 1000)]).normal(size=g.m))
        if self.comm == "oracle":
            ban = {e for e in range(g.m) if sim.observable(e, t)}
            return self._first(g, cv, w, ban)
        if self.use_obs:
            newly = []
            for e in sim.edges_in_radius(cv.node):
                b = sim.observable(e, t)
                prev = cv.own.get(e)
                cv.own[e] = (b, t, 1.0)
                if self.comm != "none" and (b and (prev is None or not prev[0] or t - cv.sent.get(e, -1e9) > cfg.tau_stale)
                                            or (not b and prev is not None and prev[0])):
                    newly.append((e, b, 1.0)); cv.sent[e] = t
            if newly:
                sim.broadcast(cv, newly, t)
        own_ban = self.banned(cv.own, t, cfg.tau_stale)
        n_in = len(cv.inbox); n_acc = 0
        if self.comm in ("all", "gate"):
            plan0 = dijkstra(g, cv.node, cv.target, w, own_ban) or []
            dd = dists(g, cv.node, g.c) if (self.comm == "gate" and self.scaling == "scaled") else None
            for m in sorted(cv.inbox, key=lambda m: m["t_obs"]):
                e = m["e"]
                age = t - m["t_obs"]
                if age > cfg.tau_stale:
                    continue
                cur = max(cv.own.get(e, (0, -1e9, 0))[1], cv.peer.get(e, (0, -1e9, 0))[1])
                if m["t_obs"] <= cur:
                    continue
                if self.comm == "gate":
                    if self.gate_fresh:
                        lim = self.eta * cfg.tau_stale if dd is None else \
                            min(cfg.tau_stale, max(1.0, self.eta * (dd[g.src[e]] + cfg.tau_msg)))
                        if age > lim:
                            sim.stats["rejected"] += 1; continue
                    if self.gate_conf and m["conf"] < self.kappa_min:
                        sim.stats["rejected"] += 1; continue
                    if self.gate_rel and m["blocked"] and e not in plan0:
                        sim.stats["rejected"] += 1; continue
                cv.peer[e] = (m["blocked"], m["t_obs"], m["conf"])
                n_acc += 1
                sim.stats["true_accepted" if m["genuine"] else "spoof_accepted"] += 1
            cv.inbox.clear()
        merged = dict(cv.peer)
        for e, v in cv.own.items():
            if e not in merged or v[1] >= merged[e][1]:
                merged[e] = v
        ban = self.banned(merged, t, cfg.tau_stale) if self.use_obs or self.comm != "none" else set()
        e_sel = self.select(sim, cv, w, ban, merged, t)
        e_own = self._first(g, cv, w, own_ban) if n_acc else e_sel
        sim.trace.append((cv.id, t, cv.node, e_sel, e_own, n_in, n_acc))
        return e_sel

    def select(self, sim, cv, w, ban, merged, t):
        return self._first(sim.g, cv, w, ban)

    @staticmethod
    def _first(g, cv, w, ban):
        p = dijkstra(g, cv.node, cv.target, w, ban)
        if p is None:
            p = dijkstra(g, cv.node, cv.target, w)
        return p[0]


def standard_methods():
    return {
        "B1": Policy("B1"),
        "B2": Policy("B2", weights="threat"),
        "B3": Policy("B3", use_obs=True),
        "NC": Policy("NC", weights="threat", use_obs=True),
        "COMM-ALL": Policy("COMM-ALL", weights="threat", use_obs=True, comm="all"),
        "GATE": Policy("GATE", weights="threat", use_obs=True, comm="gate"),
        "ORACLE": Policy("ORACLE", weights="threat", use_obs=True, comm="oracle"),
    }
