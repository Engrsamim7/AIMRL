"""Discrete-event simulator for multi-convoy contested routing.

Semantics (all documented so the paper's Eq. 2/12/13 can be matched 1:1):
  * traversal time  T_e = c_e * (1 + 0.2 * flow_e / q_e)            (Eq. 2, flow-coupled)
  * hub: `hub_cap` convoys in service at once, others wait FIFO; decision is taken at
    service end, so belief ages while a convoy queues (AoI accrues during queueing).
  * adversary blocks edge e at t0 for a duration; block is *observable* only after
    t0 + tau_reveal. A convoy entering a blocked edge is an ENCOUNTER (integer B_i); it
    is destroyed with probability p_kill (pre-sampled per (convoy, hop) => CRN-safe),
    otherwise it crosses `blocked_slow` times slower.
  * messages: broadcast by observers, delay tau_msg, loss p_loss, adversary spoofing.
"""
import heapq, itertools
from collections import deque
from dataclasses import dataclass, field
import numpy as np

DEPART, ARRIVE, SERVE_END, ATTACK, UNBLOCK, MSG, SPOOF, DEATH = range(8)


@dataclass
class Cfg:
    n_convoys: int = 12
    stagger: float = 2.0
    hub_cap: int = 2
    hub_service: float = 1.0
    tau_reveal: float = 5.0
    tau_msg: float = 2.0
    tau_stale: float = 8.0
    p_loss: float = 0.0
    spoof_rate: float = 0.0
    obs_radius: int = 1
    adv: str = "random"          # random | reactive
    attack_rate: float = 0.35
    attack_dur: tuple = (15.0, 30.0)
    budget: int = 3
    p_kill: float = 0.5
    blocked_slow: float = 2.0
    react_eps: float = 0.2
    react_halflife: float = 10.0
    horizon: float = 2000.0
    conf_mu: float = 1.0          # genuine-message confidence ~ clip(N(mu, sd), 0.05, 1); default = perfectly informative
    conf_sd: float = 0.0


@dataclass
class Convoy:
    id: int
    target: int
    depart_t: float
    node: int = 0
    alive: bool = True
    delivered: bool = False
    finished_t: float = float("nan")
    nominal: float = 0.0
    enc: int = 0
    hops: int = 0
    wait: float = 0.0
    queued_t: float = 0.0
    path: list = field(default_factory=list)
    cur_edge: int = -1
    own: dict = field(default_factory=dict)    # e -> (blocked, t_obs, conf)
    peer: dict = field(default_factory=dict)
    inbox: list = field(default_factory=list)
    sent: dict = field(default_factory=dict)
    entries: list = field(default_factory=list)   # (t, edge, was_blocked)


def _u(*key):
    return np.random.default_rng(np.random.SeedSequence(list(key))).random()


class Sim:
    def __init__(self, g, cfg, policy, seed):
        self.g, self.cfg, self.policy, self.seed = g, cfg, policy, seed
        ss = lambda tag: np.random.default_rng(np.random.SeedSequence([seed, tag]))
        r = ss(1)
        self.adv_rng = ss(2)
        self.spoof_rng = ss(3)
        self.kill_u = ss(4).random((cfg.n_convoys, 128))
        tg = r.choice(g.targets, size=cfg.n_convoys)
        dep = np.arange(cfg.n_convoys) * cfg.stagger + r.uniform(0, 1.0, cfg.n_convoys)
        self.cv = [Convoy(i, int(tg[i]), float(dep[i])) for i in range(cfg.n_convoys)]
        self.t = 0.0
        self.ev = []
        self.cnt = itertools.count()
        self.active = {}                     # e -> (t0, t1)
        self.flow = np.zeros(g.m, int)
        self.use = np.zeros(g.m)             # decayed traffic (reactive adversary)
        self.use_t = 0.0
        self.busy = np.zeros(g.n, int)
        self.queue = [deque() for _ in range(g.n)]
        self.trace = []
        self.attack_log = []
        self.stats = dict(msg_sent=0, msg_lost=0, msg_delivered=0, spoof_sent=0,
                          spoof_accepted=0, true_accepted=0, rejected=0, attacks=0)
        self.msg_seq = itertools.count()

    # ---- event plumbing
    def push(self, t, typ, payload=None):
        heapq.heappush(self.ev, (t, next(self.cnt), typ, payload))

    def observable(self, e, t):
        a = self.active.get(e)
        return a is not None and t >= a[0] + self.cfg.tau_reveal

    def edges_in_radius(self, node):
        seen, fr, out = {node}, [node], []
        for _ in range(self.cfg.obs_radius):
            nf = []
            for u in fr:
                for e in self.g.out[u]:
                    out.append(e)
                    v = int(self.g.dst[e])
                    if v not in seen:
                        seen.add(v); nf.append(v)
            fr = nf
        return out

    # ---- comms
    def broadcast(self, cv, items, t):
        for (e, blocked, conf) in items:
            for o in self.cv:
                if o.id == cv.id or o.delivered or not o.alive:
                    continue
                self.stats["msg_sent"] += 1
                k = next(self.msg_seq)
                if _u(self.seed, 5, cv.id, o.id, k) < self.cfg.p_loss:
                    self.stats["msg_lost"] += 1
                    continue
                self.push(t + self.cfg.tau_msg, MSG,
                          (o.id, dict(e=e, blocked=blocked, t_obs=t, genuine=True,
                                      conf=float(np.clip(self.cfg.conf_mu + self.cfg.conf_sd * np.random.default_rng(np.random.SeedSequence([self.seed, 6, cv.id, o.id, k])).normal(), 0.05, 1.0)) if self.cfg.conf_sd > 0 else conf)))

    # ---- adversary
    def decayed_use(self, t):
        self.use *= 0.5 ** ((t - self.use_t) / self.cfg.react_halflife)
        self.use_t = t

    def do_attack(self, t):
        c, g, rng = self.cfg, self.g, self.adv_rng
        gap = rng.exponential(1.0 / c.attack_rate)
        u1, u2, u3 = rng.random(3)
        self.push(t + gap, ATTACK)
        if len(self.active) >= c.budget:
            return
        cand = np.array([e for e in range(g.m) if e not in self.active])
        if len(cand) == 0:
            return
        if c.adv == "reactive" and u3 > c.react_eps:
            self.decayed_use(t)
            sc = self.use[cand] + 1e-6 * g.rho[cand]
            e = int(cand[int(np.argmax(sc))])
        else:
            w = g.rho[cand]; cdf = np.cumsum(w / w.sum())
            e = int(cand[min(int(np.searchsorted(cdf, u1)), len(cand) - 1)])
        dur = c.attack_dur[0] + u2 * (c.attack_dur[1] - c.attack_dur[0])
        self.active[e] = (t, t + dur)
        self.stats["attacks"] += 1
        self.attack_log.append((round(t, 9), e))
        self.push(t + dur, UNBLOCK, e)

    def do_spoof(self, t):
        c = self.cfg
        gap = self.spoof_rng.exponential(1.0 / c.spoof_rate)
        u = self.spoof_rng.random(3)
        self.push(t + gap, SPOOF)
        live = [o for o in self.cv if o.alive and not o.delivered]
        if not live:
            return
        o = live[int(u[0] * len(live))]
        # worst-case spoof: claim a block on an edge of the victim's own least-threat route
        from .graph import dijkstra
        plan = dijkstra(self.g, o.node, o.target, self.g.c * (1 + 6.0 * self.g.rho)) or [int(u[1] * self.g.m)]
        e = plan[min(int(u[1] * len(plan)), len(plan) - 1)]
        self.stats["spoof_sent"] += 1
        self.push(t + c.tau_msg, MSG, (o.id, dict(e=e, blocked=True, t_obs=t - 0.5,
                                                  conf=0.4 + 0.6 * u[2], genuine=False)))

    # ---- movement
    def enter_edge(self, cv, e, t):
        g, c = self.g, self.cfg
        T = g.c[e] * (1 + 0.2 * self.flow[e] / g.q[e])
        self.flow[e] += 1
        cv.cur_edge = e
        cv.path.append(e)
        cv.nominal += g.c[e]
        self.decayed_use(t)
        self.use[e] += 1.0
        blocked = e in self.active
        cv.entries.append((t, e, blocked))
        if blocked:
            cv.enc += 1
            if self.kill_u[cv.id, min(cv.hops, 127)] < c.p_kill:
                cv.hops += 1
                self.push(t + 0.5 * T, DEATH, cv.id)
                return
            T *= c.blocked_slow
        cv.hops += 1
        self.push(t + T, ARRIVE, (cv.id, int(g.dst[e])))

    def leave_edge(self, cv):
        if cv.cur_edge >= 0:
            self.flow[cv.cur_edge] -= 1
            cv.cur_edge = -1

    def start_service(self, cv, t):
        self.busy[cv.node] += 1
        cv.wait += t - cv.queued_t
        self.push(t + self.cfg.hub_service, SERVE_END, cv.id)

    def depart(self, cv, t):
        e = self.policy.decide(self, cv, t)
        self.enter_edge(cv, e, t)

    # ---- main loop
    def run(self, until=None):
        """Run to completion, or (until=T) pause just before time T so the live state can be inspected; call run() again to resume."""
        if not getattr(self, "_started", False):
            self._started = True
            for cv in self.cv:
                self.push(cv.depart_t, DEPART, cv.id)
            self.push(self.adv_rng.exponential(1.0 / self.cfg.attack_rate), ATTACK)
            if self.cfg.spoof_rate > 0:
                self.push(self.spoof_rng.exponential(1.0 / self.cfg.spoof_rate), SPOOF)
        remaining = sum(1 for c in self.cv if c.alive and not c.delivered)
        while self.ev and remaining > 0:
            if until is not None and self.ev[0][0] > until:
                self.t = until; return None
            t, _, typ, p = heapq.heappop(self.ev)
            if t > self.cfg.horizon:
                break
            self.t = t
            if typ == DEPART:
                self.depart(self.cv[p], t)
            elif typ == ARRIVE:
                cid, node = p
                cv = self.cv[cid]
                self.leave_edge(cv)
                cv.node = node
                if node in self.g.targets:
                    cv.delivered = True; cv.finished_t = t; remaining -= 1
                    getattr(self.policy, 'terminal', lambda *a: None)(self, cv, t, False)
                else:
                    cv.queued_t = t
                    if self.busy[node] < self.cfg.hub_cap:
                        self.start_service(cv, t)
                    else:
                        self.queue[node].append(cv)
            elif typ == SERVE_END:
                cv = self.cv[p]
                self.busy[cv.node] -= 1
                if self.queue[cv.node]:
                    self.start_service(self.queue[cv.node].popleft(), t)
                self.depart(cv, t)
            elif typ == DEATH:
                cv = self.cv[p]
                self.leave_edge(cv)
                cv.alive = False; cv.finished_t = t; remaining -= 1
                getattr(self.policy, 'terminal', lambda *a: None)(self, cv, t, True)
            elif typ == ATTACK:
                self.do_attack(t)
            elif typ == UNBLOCK:
                self.active.pop(p, None)
            elif typ == SPOOF:
                self.do_spoof(t)
            elif typ == MSG:
                cid, m = p
                o = self.cv[cid]
                if o.alive and not o.delivered:
                    o.inbox.append(m)
                    self.stats["msg_delivered"] += 1
        return self.summary()

    def summary(self):
        rows = []
        for cv in self.cv:
            ps = [1 - self.g.rho[e] for e in cv.path]
            rows.append(dict(
                route_surv=float(np.mean(ps)) if ps else float("nan"),
                max_thr=float(max((self.g.rho[e] for e in cv.path), default=float("nan"))),
                convoy=cv.id, survived=int(cv.delivered), nominal=cv.nominal,
                realized=(cv.finished_t - cv.depart_t) if cv.delivered else float("nan"),
                blocked_enc=int(cv.enc), hops=cv.hops, wait=cv.wait))
        return dict(rows=rows, trace=self.trace, stats=dict(self.stats))
